echo "Executing Insertion"
./execInsertion.sh
echo "Executing IPL"
./execIPL.sh
echo "Executing Deletions"
./execDelete.sh
echo "Executing Verbose Deletion"
./execDeleteSingle.sh
