rm resultsMetrics/*.csv
rm resultsTime/*.csv
rm instances/*
